

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 26, 2017, 6:30PM
 * Purpose: To find the miles per gallon a car drives.
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int gas=15;     //The gallons of gas the car holds
    int miTrvl=375; //The number of miles the car can travel on one full tank
    int mpg;        //The miles per gallon
    
    //Initialize variables
    
    //Input data
    mpg=miTrvl/gas;
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The car has "<<mpg<<" MPG."<<endl;
    
    //Exit stage right!
    return 0;
}

