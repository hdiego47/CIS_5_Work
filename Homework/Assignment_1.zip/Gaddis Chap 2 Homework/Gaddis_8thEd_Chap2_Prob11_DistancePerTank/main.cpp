

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 26, 2017, 6:43 PM
 * Purpose: To find the distance per tank of gas a car has
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float gas=20;         //The amount of gallons of gas the car can hold
    float mpgTwn=23.5f;   //The miles per gallon the car has in a town
    float mpgHwy=28.9f;   //The miles per gallon the car has on the highway
    float disTwn, disHwy; //The distance the car can travel in a full tank
                          // either in a town or on the highway
    
    //Initialize variables
    
    //Input data
    disTwn=gas*mpgTwn;
    disHwy=gas*mpgHwy;
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The distance the car can travel in one tank of gas in town is "<<
            disTwn<<" miles."<<endl;
    cout<<"The distance the car can travel in one tank of gas on a highway is "
            <<disHwy<<" miles."<<endl;
    
    //Exit stage right!
    return 0;
}

