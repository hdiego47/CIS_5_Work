

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 23, 2017, 4:14 PM
 * Purpose: To predict how much money in sales the East Coast division will
 *          generate
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants
const float MILLION=1.0e6f; //Conversion factor for millions

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float percSls=.58f; //Percent of sales from the East Coast division
    float sales=8.6e6f; //Sales made this year in millions
    float slsGrtd;      //Prediction of how much the East Coast will generate
    
    //Initialize variables
    
    //Input data
    slsGrtd=percSls*sales;
    
    //Map inputs to outputs or process the data
    cout<<"The East Coast division will generate about $"<<slsGrtd/MILLION
            <<" Million dollars in sales"<<endl;
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

