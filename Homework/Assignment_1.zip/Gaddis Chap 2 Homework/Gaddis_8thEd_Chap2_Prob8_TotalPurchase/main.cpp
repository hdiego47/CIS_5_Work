

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 26, 2017, 6:04PM
 * Purpose: To find the total price of five items
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float item1=15.95f;                 //The price of item 1 in dollars
    float item2=24.95f;                 //The price of item 2 in dollars
    float item3=6.95f;                  //The price of item 3 in dollars
    float item4=12.95f;                 //The price of item 4 in dollars
    float item5=3.95f;                  //The price of item 5 in dollars
    float tax=0.07f;                    //The percent sales tax
    float subTtl, taxTtl, total,        //The subtotal, tax total, and total
          tax1, tax2, tax3, tax4, tax5; //The tax of each item
    
    //Initialize variables
    
    //Input data
    subTtl=item1+item2+item3+item4+item5;
    tax1=item1*tax;
    tax2=item2*tax;
    tax3=item3*tax;
    tax4=item4*tax;
    tax5=item5*tax;
    taxTtl=tax1+tax2+tax3+tax4+tax5;
    total=subTtl+taxTtl;
    
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The price of item 1 is $"<<item1<<endl;
    cout<<"The price of item 2 is $"<<item2<<endl;
    cout<<"The price of item 3 is $"<<item3<<endl;
    cout<<"The price of item 4 is $"<<item4<<endl;
    cout<<"The price of item 5 is $"<<item5<<endl;
    cout<<"The subtotal of the sale is $"<<subTtl<<endl;
    cout<<"The amount of sales tax is $"<<taxTtl<<endl;
    cout<<"The total amount owed by the customer is $"<<total<<endl;
    
    //Exit stage right!
    return 0;
}

