

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 23, 2017, 4:33 PM
 * Purpose: To compute sales tax
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float slsTax=0.04f;  //state sales tax
    float cSlsTax=0.02f; //country sales tax
    float prchase=95;    //purchase total in dollars
    float taxTotl;
    
    //Initialize variables
    
    //Input data
    taxTotl=(slsTax+cSlsTax)*prchase;
    
    //Map inputs to outputs or process the data
    cout<<"The total sales tax on this $95 dollar purchase was $"<<taxTotl<<
            " dollars"<<endl;
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

