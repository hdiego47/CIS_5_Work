

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 26, 2017, 3:55 PM
 * Purpose: To calculate the annual pay of an employee
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float payAmnt=2200.0f; //The amount of money payed each par period
    float payPrds=26;      //Amount of times payed each year
    float anPay;           //The amount of pay received each year
    
    //Initialize variables
    
    //Input data
    anPay=payAmnt*payPrds;
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The annual pay for this employee is $"<<anPay<<" dollars."<<endl;
    
    //Exit stage right!
    return 0;
}

