

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 23, 2017, 4:46 PM
 * Purpose: To compute the tax and tip on a restaurant bill
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float charge=88.67f; //total meal charge
    float tax=.0675f;     //The tax percent of the meal cost
    float tip=0.20f;     //Tip percent with the tax already included
    float mealCst, taxAmnt, tipAmnt, totlBil; //The meal cost, tax amount,
                                              //tip amount, and total meal cost
    
    //Initialize variables
    
    //Input data
    taxAmnt=charge*tax;
    mealCst=charge-taxAmnt;
    tipAmnt=charge*tip;
    totlBil=charge+tipAmnt;
    
    //Map inputs to outputs or process the data
    cout<<"The cost of the meal was $"<<mealCst<<" dollars"<<endl;
    cout<<"The tax amount of the meal was $"<<taxAmnt<<" dollars"<<endl;
    cout<<"The tip amount of the meal was $"<<tipAmnt<<" dollars"<<endl;
    cout<<"The total bill of the meal was $"<<totlBil<<" dollars"<<endl;
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

