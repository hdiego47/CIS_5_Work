

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 23, 2017, 4:06 PM
 * Purpose: Two add two integers
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int frstNum=50;  //The first integer to be added
    int scndNum=100; //The second integer to be added
    int total;       //The sum of the two integers
    
    //Initialize variables
    
    //Input data
    total=frstNum+scndNum;
    
    //Map inputs to outputs or process the data
    cout<<"The sum of 50 and 100 is "<<total<<endl;
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

