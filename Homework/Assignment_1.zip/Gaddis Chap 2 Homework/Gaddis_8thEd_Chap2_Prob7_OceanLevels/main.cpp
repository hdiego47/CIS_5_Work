

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 26, 2017, 5:43 PM
 * Purpose: To predict how much higher the ocean level will be above the current level
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float riseLvl=1.5f;      //The current rise of the ocean each year in millimeters
    float lvl5, lvl7, lvl10; //How much the ocean will rise in 5, 7, and 10 years
    
    //Initialize variables
    
    //Input data
    lvl5=riseLvl*5;
    lvl7=riseLvl*7;
    lvl10=riseLvl*10;
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The ocean will be "<<lvl5<<" millimeters higher than the current level "
            "in five years."<<endl;
    cout<<"The ocean will be "<<lvl7<<" millimeters higher than the current level "
            "in seven years."<<endl;
    cout<<"The ocean will be "<<lvl10<<" millimeters higher than the current level "
            "in ten years."<<endl;
    
    //Exit stage right!
    return 0;
}

