

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 23, 2017, 5:16 PM
 * Purpose: To get the average of five values
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int valOne=28; //the first value
    int valTwo=32; //the second value
    int valThre=37;//the third value
    int valFour=24;//the fourth value
    int valFive=33;//the fifth value
    float sumVal;    //the sum of all the values
    float average; //the average of the values
    
    //Initialize variables
    
    //Input data
    sumVal=valOne+valTwo+valThre+valFour+valFive;
    average=sumVal/5;
    
    //Map inputs to outputs or process the data
            cout<<"The average of the five values is "<<average<<endl;
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

