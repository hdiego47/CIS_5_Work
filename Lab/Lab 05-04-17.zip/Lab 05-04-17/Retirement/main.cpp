

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 4, 2017, 11:33 AM
 * Purpose: To calculate how much you need to save to retire
 */

//System Libraries
#include <iostream> //Imput - Output Library
#include <iomanip>
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int yrsWrkg=50;         //Years Working
    float intRate=.05f;     //Interest rate
    float salary=100000.0f; //Salary
    float prcSave=.20f;     //Percent salary to save per year
    float yrlyDep; //Yearly deposit
    float intPay=0.0f;      //Interest payed per year
    float svBlnce=0.0f;     //Savings balance
    int year=2022;
    
    //Map inputs to outputs or process the data
    cout<<"Worked  Year     Balance    interest    Deposit"<<endl;
    for(int i=0;i<=yrsWrkg;i++){
        yrlyDep=salary*prcSave;
        intPay=svBlnce*intRate;
        svBlnce=svBlnce+intPay+yrlyDep;
        cout<<"  "<<i<<"      "<<year<<"      "<<svBlnce<<"     "<<intPay<<"     "
                <<yrlyDep<<endl;
        year++;
    }
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

