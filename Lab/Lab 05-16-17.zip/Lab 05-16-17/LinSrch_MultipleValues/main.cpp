/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 16, 2017, 12:05 PM
 * Purpose:  Linear Search with multiple variables
 */

//System Libraries Here
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void filAray(int [],int,int);
void prntAry(int [],int,int);
void allSrch(int [],int,int);
int linSrch(int [],int,int,int);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Random Number Generator
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here

    //Exit
    return 0;
}

void allSrch(int a[],int n,int val){
    int pos=0;
    do{
        pos=linSrch(a,pos,n,val);
        if(pos>=0)cout<<val<<" found at "<<pos<<endl;
    }while(pos++>=0);
    
}

int linSrch(int a[],int b,int e,int val){
    for(int i=b;i<e;i++){
        if(a[i]==val)return 1;
    }
    return -1;
}

void prntAry(int a[],int n,int perLine){
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
}

void filAray(int a[],int n,int mod){
    for(int i=0;i<n;i++){
        a[i]=i%mod;
    }
}