/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 16, 2017, 10:36 AM
 * Purpose:  Grading your DMN tests
 */

//System Libraries Here
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries Here

//Global Constants

//Function Prototypes
void rdFile(string,char [],int);   //read the answer key and student response
void wrtFile(string,int [],int);  //Write the result
void grade(char [],char [],int [],int);//Compare and grade
int score(int [],int);               //Numerical result

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=20;
    char key[SIZE],stuResp[SIZE];
    int scr[SIZE]={};
    string keyFn,stuRFn,scoreFn;
    
    //Initialize string variables
    keyFn="key.dat";
    stuRFn="answer.dat";
    scoreFn="result.dat";
    
    //Input data
    rdFile(keyFn,key,SIZE);
    rdFile(stuRFn,stuResp,SIZE);
    
    //Process/Calculations Here
    grade(key,stuResp,scr,SIZE);
    
    
    //Output Located Here
    cout<<"Your Test result score was = "<<score(scr,SIZE)<<endl;
    wrtFile(scoreFn,scr,SIZE);

    //Exit
    return 0;
}

void wrtFile(string fn,int pts[],int n){
     //Declare variables
    ofstream out;
    //open file
    out.open(fn.c_str());
    //Read the values
    for(int i=0;i<n;i++){
        out<<pts[i]<<endl;
    }
    //close the file
    out.close();
}

int score(int pts[],int n){
    int sum=0;
    for(int i=0;i<n;i++){
        sum+=pts[i];;
    }
    return sum;
}

void grade(char key[],char stu[],int pts[],int n){
    for(int i=0;i<n;i++){
        if(key[i]==stu[i])pts[i]=1;
    }
}

void rdFile(string fn,char a[],int n){
    //Declare variables
    ifstream in;
    int cnt=0;
    //open file
    in.open(fn.c_str());
    //Read the values
    while(in>>a[cnt++]&&cnt<n);
    //close the file
    in.close();
}
