

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 14, 2017, 11:29 AM
 * Purpose: 
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    unsigned short hrsWrkd,payRt,payChk;//pay rate in $'s and hours worked
    
    //Input data
    cout<<"This program calculates your paycheck"<<endl;
    cout<<"Type your pay rate and hours worked"<<endl;
    cin>>payRt>>hrsWrkd;
    
    //Map inputs to outputs or process the data
    if(hrsWrkd<=40)payChk=payRt*hrsWrkd;
    if(hrsWrkd>40)payChk=payRt*hrsWrkd+payRt*(hrsWrkd-40);
    
    
    //Output the transformed data
    cout<<"Your paycheck is $"<<payChk<<endl;
    
    //Exit stage right!
    return 0;
}

