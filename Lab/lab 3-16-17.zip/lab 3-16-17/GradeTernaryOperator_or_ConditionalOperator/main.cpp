

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on March 16, 2017, 11:26 AM
 * Purpose: To use the Ternary Operator or the Conditional Operator
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    unsigned short score;//integer scores valid from 0 to 100
    char grade;
        
    //Input data
    cout<<"This program produces a grade from a score input"<<endl;
    cout<<"The data type used is an integer [0-100]"<<endl;
    cout<<"Type in the score"<<endl;
    cin>>score;
    if(!(score>=0&&score<=100)){
        cout<<"You failed to type an integer between 0 and 100"<<endl;
        return 1;
    }//use DeMorgans Law to make clearer
    
    //Map inputs to outputs or process the data
    grade=(score>=90)?'A':
          (score>=80)?'B':
          (score>=70)?'C':
          (score>=60)?'D':'F';
    
    
    //Output the transformed data
    cout<<"For a score = "<<score<<" your grade is a(n) "<<grade<<endl;
    
    //Exit stage right!
    return 0;
}

