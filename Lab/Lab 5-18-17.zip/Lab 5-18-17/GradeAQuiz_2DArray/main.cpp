/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 16, 2017, 10:36 AM
 * Purpose:  Grading your DMN tests
 */

//System Libraries Here
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries Here

//Global Constants
const int COLS=3;

//Function Prototypes
void rdFile(char [],char [],char [][COLS],int);//read the answer key and student response
void wrtFile(string,char [][COLS],int);       //Write the result
void grade(char [][COLS],int);                //Compare and grade
int score(char [][COLS],int);                 //Numerical result

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=20;
    char kyRspScr[SIZE][COLS]={};
    string scoreFn;
    
    //Initialize string variables
    char keyFn="key.dat";
    char stuRFn="answer.dat";
    scoreFn="result.dat";
    
    //Input data
    rdFile(keyFn,kyRspScr,SIZE);
   
    
    //Process/Calculations Here
    grade(kyRspScr,SIZE);
    
    
    
    //Output Located Here
    cout<<"Your Test result score was = "<<score(kyRspScr,SIZE)<<endl;
    wrtFile(scoreFn,kyRspScr,SIZE);

    //Exit
    return 0;
}

void wrtFile(string fn,char krp[][COLS],int n){
     //Declare variables
    ofstream out;
    //open file
    out.open(fn.c_str());
    //Read the values
    for(int i=0;i<n;i++){
        out<<static_cast<int>(krp[i][2])<<endl;
    }
    //close the file
    out.close();
}

int score(char krp[][COLS],int n){
    int sum=0;
    for(int i=0;i<n;i++){
        sum+=krp[i][2];;
    }
    return sum;
}

void grade(char krp[][COLS],int n){
    for(int i=0;i<n;i++){
        if(key[i]==krp[i][1])krp[i][2]=1;
    }
}

void rdFile(char fn1,char fn2[],char krp[][COLS],int n){
    //Declare variables
    ifstream in1;
    int cnt=0;
    //open file
    in.open(fn.c_str());
    //Read the values
    while(in1>>a[cnt++][0]&&cnt<n);
    //close the file
    in.close();
    //Declare variables for the response file
    ifstream 1n2;
    int cnt=0;
    //Open the file
    in2.open(fn1);
    //Read the values
    while(in1>>a[cnt++][0]&&cnt<n);
    //Close the file
    in.close();
}
