/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 16, 2017, 10:36 AM
 * Purpose:  Grading your DMN tests
 */

//System Libraries Here
#include <iostream> //Input - Output Library
#include <fstream>  //Reading/writing to files
#include <vector>   //The STL Vecotr -> Dynamic Array
using namespace std;//Name-space under which system libraries are located

//User Libraries Here

//Global Constants

//Function Prototypes
void rdFile(string,vector<char> &);   //read the answer key and student response
void wrtFile(string,vector<int> &);  //Write the result
void grade(vector<char> &,vector<char> &,vector<int> &);//Compare and grade
int  score(vector<int> &);               //Numerical result

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=20;
    vector<char> key[SIZE];
    vector<char>stuResp[SIZE];
    vector<int> scr[SIZE]={};
    string keyFn,stuRFn,scoreFn;
    
    //Initialize string variables
    keyFn="key.dat";
    stuRFn="answer.dat";
    scoreFn="result.dat";
    
    //Input data
    rdFile(keyFn,key);
    rdFile(stuRFn,stuResp);
    
    //Process/Calculations Here
    grade(key,stuResp,scr);
    
    
    //Output Located Here
    cout<<"Your Test result score was = "<<score(scr)<<endl;
    wrtFile(scoreFn,scr);

    //Exit
    return 0;
}

void wrtFile(string fn,vector<int> &pts){
     //Declare variables
    ofstream out;
    //open file
    out.open(fn.c_str());
    //Read the values
    for(int i=0;i<pts.size();i++){
        out<<pts[i]<<endl;
    }
    //close the file
    out.close();
}

int score(vector<int> &pts){
    int sum=0;
    for(int i=0;i<pts.size();i++){
        sum+=pts[i];;
    }
    return sum;
}

void grade(vector<char> &key,vector<char> &stu,vector<int> &pts){
    for(int i=0;i<pts.size();i++){
        if(key[i]==stu[i])pts[i]=1;
    }
}

void rdFile(string fn,vector<char> &a){
    //Declare variables
    ifstream in;
    int cnt=0;
    //open file
    in.open(fn.c_str());
    //Read the values
    while(in>>a[cnt++]&&cnt<a.size());
    //close the file
    in.close();
}
