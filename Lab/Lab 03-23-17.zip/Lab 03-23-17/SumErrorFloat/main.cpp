

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on March 23, 2017, 11:48 AM
 * Purpose: Brute force sum compare to multiplication
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare and initialize variables
    int nLoop=10000000;
    float sum=0.0f,frac=0.1f;
    
    //Input data
    
    //Map inputs to outputs or process the data
    for(int i=1;i<=nLoop;i++){
        sum+=frac;
    }
    
    //Output the transformed data
    cout<<"The computed sum of "
            <<frac<<"->"<<nLoop<<" times = "<<sum<<endl;
    cout<<"Simple multiplication of "
            <<frac<<"X"<<nLoop<<" = "<<frac*nLoop<<endl;
    cout<<"Error = "<<(frac*nLoop-sum)/(frac*nLoop)*100
            <<"%"<<endl;
    
    //Exit stage right!
    return 0;
}

