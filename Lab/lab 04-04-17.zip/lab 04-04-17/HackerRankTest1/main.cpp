

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on April 4, 2017, 12:00 AM
 * Purpose: Hacker Rank Test 1
 */

//System Libraries
#include <iostream> //Imput - Output Library
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int n,fact=1;
    
    //Initialize variables
    
    //Input data
    cout<<"Please input an integer for n"<<endl;
    cin>>n;
    
    //Map inputs to outputs or process the data
    for(int i=1;i<=n;i++){
        fact*=i;
    }
    cout<<n<<"! = "<<fact<<endl;
    
    //solve second part
    float x;
    cout<<endl<<"Second part, calculate e^x"<<endl;
    cout<<"Type in x"<<endl;
    cin>>x;
    float etox
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

