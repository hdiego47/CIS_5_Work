/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on May 11, 2017, 11:25 AM
 * Purpose:  Mark Sort without functions
 */

//System Libraries Here
#include <iostream> //Input and output library
#include <cstdlib>  //random number function
#include <ctime>    //time to set the seed
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Random number generator
    srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
    const int SIZE=100;
    int array[SIZE]={};
    
    //Fill Array
    for(int indx=0;indx<SIZE;indx++){
        (*(array+indx))=rand()%90+10;//Fill with 2 digit number
    }
    
    //Print Array
    int perLine=10;
    cout<<endl;
    for(int indx=0;indx<SIZE;indx++){
        cout<<(*(array+indx))<<" ";
        if(indx%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
   
    //Mark Sort
    for(int pos=0;pos<SIZE-1;pos++){
        for(int indx=pos;indx<SIZE;indx++){
           if((*(array+pos))>(*(array+indx))){
             int temp=(*(array+pos));
             (*(array+pos))=(*(array+indx));
             (*(array+indx))=temp;
            }
        }
    }
    
    //Print Array
    cout<<endl;
    for(int indx=0;indx<SIZE;indx++){
        cout<<(*(array+indx))<<" ";
        if(indx%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;

    //Exit
    return 0;
}