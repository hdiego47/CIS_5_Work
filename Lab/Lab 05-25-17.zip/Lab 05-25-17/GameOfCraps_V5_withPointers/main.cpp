

/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on February 14, 2017, 11:29 AM
 * Purpose: Project 2 - To simulate playing a Craps game
 */

//System Libraries
#include <iostream> //Imput - Output Library
#include <ctime>    //Time for rand
#include <cstdlib>  //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
using namespace std; //Namespace under which system libraries exist

//User Libraries

//Global Constants
const float PERCENT=100.0f;//Conversion to percent

//Function Prototypes
char rollDie(int);                                     //Roll the die
void fileDsp(ofstream &,int *,int *,int,int,int,int);//File display
void scrnDsp(int *,int *,int,int,int,int);           //Screen display
void crpGame(int *,int *,int,int &,int &,int &);     //Play Craps

//Execution begins here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare variables
    ifstream in;
    ofstream out;
    int nGames;
    int mxThrw=0,numThrw=0,lmGames=100000;
    const int SIZE=13;   //size of our arrays
    int wins[SIZE]={};   //initializing the win array
    int losses[SIZE]={}; //initializing the loss arry
    
    //Initialize variables
    in.open("GameInfo.dat");
    out.open("GameStats.dat");
    while(in>>nGames);//Last value becomes the number of games
    nGames=nGames>lmGames?lmGames:nGames;
    
    //Play the Game
    crpGame(wins,losses,SIZE,nGames,numThrw,mxThrw);
    
    //Output the transformed data
    scrnDsp(wins,losses,SIZE,nGames,numThrw,mxThrw);
    
    //Output the transformed data to a file
    fileDsp(out,wins,losses,SIZE,nGames,numThrw,mxThrw);
    
    
    //Exit stage right!
    in.close();
    out.close();
    return 0;
}

void crpGame(int *wins,int *losses,int SIZE,int &nGames,int &numThrw,int &mxThrw){
    for(int game=1;game<=nGames;game++){
        //Throw dice and sum
        int gmThrw=1;
        char sum1=rollDie(6);
        //Determine wins and losses
        switch(sum1){
            case 7:
            case 11:(*(wins+sum1))++;break;
            case  2:
            case  3:
            case 12:(*(losses+sum1))++;break;
            default:{
                //loop until a 7 or previous sum is thrown
                bool thrwAgn=true;
                do{
                    //Throw the dice again
                    char sum2=rollDie(6);
                    gmThrw++;
                    if(sum2==7){
                        (*(losses+sum1))++;
                        thrwAgn=false;
                    }else if(sum1==sum2){
                        (*(wins+sum1))++;
                        thrwAgn=false;
                    }

                }while(thrwAgn);//do-while
            }
        }
        numThrw+=gmThrw;
        if(mxThrw<gmThrw)mxThrw=gmThrw;//Independent if
    }
    
}

void fileDsp(ofstream &out,int *wins,int *losses,int SIZE,int nGames,int numThrw,int mxThrw){
    out<<fixed<<setprecision(2);showpoint;
    out<<"Total number of Games = "<<nGames<<endl;
    out<<"Roll    Wins   Losses"<<endl;
    int sWins=0,sLosses=0;
    for(int sum=2;sum<SIZE;sum++){
        sWins+=(*(wins+sum));
        sLosses+=(*(losses+sum));
        out<<setw(4)<<sum<<setw(8)<<(*(wins+sum))<<setw(8)<<(*(losses+sum))<<endl;
    }
    out<<"Total wins and losses = "<<sWins+sLosses<<endl;
    out<<"Percentage wins       = "
            <<static_cast<float>(sWins)/nGames*PERCENT<<"% "<<endl;
     out<<"Percentage Losses     = "
            <<static_cast<float>(sLosses)/nGames*PERCENT<<"& "<<endl;
     out<<"Maximum number of throws in a game = "<<mxThrw<<endl;
     out<<"Average throw per game = "<<static_cast<float>(numThrw)/nGames<<endl;
     
}

void scrnDsp(int *wins,int *losses,int SIZE,int nGames,int numThrw,int mxThrw){
    cout<<fixed<<setprecision(2);showpoint;
    cout<<"Total number of Games = "<<nGames<<endl;
    cout<<"Roll    Wins   Losses"<<endl;
    int sWins=0,sLosses=0;
    for(int sum=2;sum<SIZE;sum++){
        sWins+=(*(wins+sum));
        sLosses+=(*(losses+sum));
        cout<<setw(4)<<sum<<setw(8)<<(*(wins+sum))<<setw(8)<<(*(losses+sum))<<endl;
    }
    cout<<"Total wins and losses = "<<sWins+sLosses<<endl;
    cout<<"Percentage wins       = "
            <<static_cast<float>(sWins)/nGames*PERCENT<<"% "<<endl;
     cout<<"Percentage Losses     = "
            <<static_cast<float>(sLosses)/nGames*PERCENT<<"& "<<endl;
     cout<<"Maximum number of throws in a game = "<<mxThrw<<endl;
     cout<<"Average throw per game = "<<static_cast<float>(numThrw)/nGames<<endl;
     
}

char rollDie(int sides){
    char die1=rand()%sides+1;//[1,6]
    char die2=rand()%sides+1;
    char sum1=die1+die2;
    return sum1;
}